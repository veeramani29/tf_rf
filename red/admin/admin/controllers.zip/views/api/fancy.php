<?php
print_r($items);
?>