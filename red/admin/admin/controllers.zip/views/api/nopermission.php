<div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div>
    <ul class="breadcrumb">
        <li>
            <a href="#">Home</a>
        </li>
        <li>
            <a href="#">Dashboard</a>
        </li>
    </ul>
</div>
<div class="row">
<center>
<h3>You must be an administrator to view this page.</h3>
</center>
</div>
    <!-- content ends -->
    </div><!--/#content.col-md-0-->