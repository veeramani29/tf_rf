<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo Site_Title; ?></title>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top" bgcolor="#726627" style="background-color:#fff;"><br>
    <br>
    <table width="600" border="0" cellspacing="0" cellpadding="0" style='border:1px solid #a2b417;'>
     <!-- <tr>
        <td align="left" valign="top" style="padding:5px;"><img src="images/company-logo.png" width="100" height="67" style="display:block;"></td>
      </tr> -->
<!--      <tr>
        <td align="left" valign="top"><img src="<?php echo base_url() ?>assets/images/top.png" width="600" height="133" style="display:block;">
	</td>
      </tr>-->
      <tr>
        <td align="center" valign="top" bgcolor="#006c00" style="background-color:#a2b417; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000000;"><table width="100%" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td width="50%" align="left" valign="top" style="color:#ffffff; font-family:Verdana, Geneva, sans-serif; font-size:11px;">Hello, <?php echo $name; ?></td>
            <td align="right" valign="top" style="color:#ffffff; font-family:Verdana, Geneva, sans-serif; font-size:11px;"><?php echo date('Y-m-d'); ?></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#ffffff" style="background-color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000000; padding:12px;"><table width="100%" border="0" cellspacing="0" cellpadding="10" style="margin-bottom:10px;">
          <tr>
            <td align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#525252;">
                <div style="font-size:22px;">Welcome To <?php echo Site_Title; ?>  Your Travel Expert Provider "</div>
            <div style="font-size:18px; color:#006d00;">Your Registration is confirmed.</div>
              
<div>  
        <p>Thank you Agent for registering with us. The best hotel travel deals are waiting for you at the lowest rates. Your account will be validated by Admin and will be activated within 24 hours.</p>
        <p>Below are your login details, keep it safe and don't share it with any one.</p>
        <p>Username : <?php echo $user_email ?></p>
        <p>Password : <?php echo $pass ?></p>
</div> </td>
          </tr>
        </table>
          
          </td>
      </tr>
<!--      <tr>
        <td align="left" valign="top" bgcolor="#a2b417" style="background-color:#a2b417;"><table width="100%" border="0" cellspacing="0" cellpadding="15">
          <tr>
            <td align="left" valign="top" style="color:#ffffff; font-family:Arial, Helvetica, sans-serif; font-size:13px;">CORPORATE OFFICE:<br>
              FORT LEGEND TOWER Level 10-1 <br>
31st Street & 3rd Ave, <br>
Bonifacio Global City,<br> Taguig City 1632, NCR, Philippines 
             </td>
          </tr>
        </table></td>
      </tr>-->
  </table>
    <br>
    <br></td>
  </tr>
</table>
</body>
</html>
