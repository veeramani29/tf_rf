function setPriceSlider()
{
    var setPriceMin=parseFloat($("#setMinPrice").val());
    var setPriceMax=parseFloat($("#setMaxPrice").val());
    var currency=$("#setCurrency").val();
    callPriceSlider(setPriceMin,setPriceMax,currency);
    
    var setPriceMinR=parseFloat($("#RsetMinPrice").val());
    var setPriceMaxR=parseFloat($("#RsetMaxPrice").val());
    var currencyR=$("#RsetCurrency").val();
    callPriceSliderR(setPriceMinR,setPriceMaxR,currencyR);
    
    priceSorting();
}

function callPriceSlider(setPriceMin,setPriceMax,currency)
{	
    $selector=$( "#priceSlider" );
    $output=$( "#priceSliderOutput");
    $minPrice=$("#minPrice");
    $maxPrice=$("#maxPrice");
    $selector.slider
    ({
        range: true,
        min: setPriceMin,
        max: setPriceMax,
        values: [setPriceMin, setPriceMax],
        slide: function(event, ui)
        {
            if(ui.values[0]+20>=ui.values[1])
            {
                return false;
            }
            else
            {                
                $output.html("<span style='color:red'>"+currency+' '+ ui.values[ 0 ] + "</span> to <span style='color:red'>"+currency+' '+ui.values[ 1 ] +"</span>");
                $minPrice.val(ui.values[0]);
                $maxPrice.val(ui.values[1]);                
            }
        }
    });
    
    $output.html("<span style='color:red'>"+currency+' '+$selector.slider( "values", 0 ) + "</span> To <span style='color:red'>"+currency+' '+ $selector.slider( "values",1) +"</span>");
    $minPrice.val($selector.slider( "values",0));
    $maxPrice.val($selector.slider( "values",1));
}

function callPriceSliderR(setPriceMin,setPriceMax,currency)
{	
    $selector=$( "#RpriceSlider" );
    $output=$( "#RpriceSliderOutput");
    $minPrice=$("#RminPrice");
    $maxPrice=$("#RmaxPrice");
    $selector.slider
    ({
        range: true,
        min: setPriceMin,
        max: setPriceMax,
        values: [setPriceMin, setPriceMax],
        slide: function(event, ui)
        {
            if(ui.values[0]+20>=ui.values[1])
            {
                return false;
            }
            else
            {                
                $output.html("<span style='color:red'>"+currency+' '+ ui.values[ 0 ] + "</span> to <span style='color:red'>"+currency+' '+ui.values[ 1 ] +"</span>");
                $minPrice.val(ui.values[0]);
                $maxPrice.val(ui.values[1]);                
            }
        }
    });
    
    $output.html("<span style='color:red'>"+currency+' '+$selector.slider( "values", 0 ) + "</span> To <span style='color:red'>"+currency+' '+ $selector.slider( "values",1) +"</span>");
    $minPrice.val($selector.slider( "values",0));
    $maxPrice.val($selector.slider( "values",1));
}

function priceSorting()
{
    $(".ui-slider").bind( "slidestop", function() 
    {
        filter();
    });
}

function filter()
{ 	
    $minPr=parseFloat($("#minPrice").val());
    $maxPr=parseFloat($("#maxPrice").val());   
    
    $minPrR=parseFloat($("#RminPrice").val());
    $maxPrR=parseFloat($("#RmaxPrice").val());
    
    
    $stops = new Array;
    $airlines = new Array;
    
    $stopsR = new Array;
    $airlinesR = new Array;
    
    $(".stop_filter:checked").each(function()
    {
        $stopsNum=parseFloat($(this).val());
        $stops.push($stopsNum); 
    });  
    
    $(".air_filter:checked").each(function()
    {
        $airlineNum=$(this).val();
        $airlines.push($airlineNum); 
    });
    
    $(".Rair_filter:checked").each(function()
    {
        $airlineNumR=$(this).val();
        $airlinesR.push($airlineNumR); 
    });
    
    $(".Rstop_filter:checked").each(function()
    {
        $stopsNumR=parseFloat($(this).val());
        $stopsR.push($stopsNumR); 
    });  
    
   
    
   

  
    flightCount = 0;
    $(".FlightInfoBox").each(function()
    {
        $datastops=parseFloat($(this).attr("data-stops"));
	$dataairline=$(this).attr("data-airlines");
        $dataprice=parseFloat($(this).attr("data-price"));
       
        
        var stopsShow=$.inArray($datastops, $stops)>=0?true:false;
        var airlineShow=$.inArray($dataairline, $airlines)>=0?true:false;
        
        $datastopsR=parseFloat($(this).attr("data-Rstops"));
	$dataairlineR=$(this).attr("data-Rairlines");
        $datapriceR=parseFloat($(this).attr("data-Rprice"));
        
        var stopsShowR=$.inArray($datastopsR, $stopsR)>=0?true:false;
        var airlineShowR=$.inArray($dataairlineR, $airlinesR)>=0?true:false;
        
        
        if(($dataprice<=$maxPr && $dataprice>=$minPr) && ($datapriceR<=$maxPrR && $datapriceR>=$minPrR) && stopsShow && stopsShowR && airlineShowR && airlineShow)
        {
            flightCount++;
            $(this).parents(".searchflight_box").show();
            $(this).parents(".Rsearchflight_box").show();
        }
        else
        {
            $(this).parents(".searchflight_box").hide();
            $(this).parents(".Rsearchflight_box").hide();
        }
    });  
    
    $(".RFlightInfoBox").each(function()
    {
        $datastops=parseFloat($(this).attr("data-stops"));
	$dataairline=$(this).attr("data-airlines");
        $dataprice=parseFloat($(this).attr("data-price"));
        
        var stopsShow=$.inArray($datastops, $stops)>=0?true:false;
        var airlineShow=$.inArray($dataairline, $airlines)>=0?true:false;
        
        $datastopsR=parseFloat($(this).attr("data-Rstops"));
	$dataairlineR=$(this).attr("data-Rairlines");
        $datapriceR=parseFloat($(this).attr("data-Rprice"));
        
        var stopsShowR=$.inArray($datastopsR, $stopsR)>=0?true:false;
        var airlineShowR=$.inArray($dataairlineR, $airlinesR)>=0?true:false;
        
        
        if(($dataprice<=$maxPr && $dataprice>=$minPr) && ($datapriceR<=$maxPrR && $datapriceR>=$minPrR) && stopsShow && stopsShowR && airlineShowR && airlineShow)
        {
            flightCount++;
            $(this).parents(".searchflight_box").show();
            $(this).parents(".Rsearchflight_box").show();
        }
        else
        {
            $(this).parents(".searchflight_box").hide();
            $(this).parents(".Rsearchflight_box").hide();
        }
    });  
    
    
}
