<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//General
$lang['TRAVELLER_BES_TFRND']="The traveller's best friend";
$lang['DEAR']='Dear';
$lang['MAIL_USERNAME']='Username';
$lang['MAIL_PASSWORD']='Password';
$lang['MAIL_THANKS_MSG']='Thank you for using '.WEB_NAME.' online booking system.';
// Registration Mail
$lang['REG_THANKS']='Thank you for registering';
$lang['CONFIRM_MSG']='Welcome to the '.WEB_NAME.' In order to get started, you need to confirm your email address.';
$lang['CLICK_CONFIRM']='Click here to Confirm Email';
// Registration Mail
$lang['RESET_PASSWORD_LINK']='Reset password link';
$lang['RESET_PASSWORD_MSG']="We've received a request to reset your password. If you didn't make the request, just ignore this email. Otherwise, you can reset your password using this link:";
$lang['CLICK_PASSWORD']='Click here to reset your password';

// Flight Mail Voucher,Invoice,Cancel
$lang['Booking_Voucher']='Booking Voucher';
$lang['Hello']='Hello';
$lang['Customer_Details']='Customer_Details';
$lang['Booking_Voucher_Msg']='Thanks for using '.WEB_NAME.'. Your booking details are below :';
$lang['INVOICE']='Invoice';
$lang['Receive_Payment']='Receive Payment';
$lang['Payment_Details']='Payment Details';
$lang['Flight_Info']='Flight Info';
$lang['Total_Amount']='Total Amount';
$lang['Booking_Cancel']='Booking Cancel';
$lang['Cancellation_Details']='Cancellation Details';
$lang['CANCEL_MSG']='Your booking  is cancelled no';
// Hotel Mail Voucher,Invoice,Cancel
$lang['Booking_Details']='Booking Details';

$lang['ADVISED_MSG']="You'r advised to print the Voucher in the attachment above for your convenience. You'r requested to present this voucher upon your arrival at hotel front desk.";





//NOTe PLEASE DONT edit ('.WEB_NAME.') This  string




