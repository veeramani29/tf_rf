<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Oauth2callback extends CI_Controller {
	
 public function __construct(){
        parent::__construct();
	}
    public function index(){
    // $this->load->view('apartment/booking1');
    }
	 
	
    
}

/* End of file apartment.php */
/* Location: ./application/controllers/apartment.php */
