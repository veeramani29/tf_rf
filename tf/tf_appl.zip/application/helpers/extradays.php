<?php 
   /* $a='<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header />
   <soapenv:Body>
      <air:LowFareSearchReq xmlns:air="http://www.travelport.com/schema/air_v28_0" TargetBranch="P7028803" AuthorizedBy="user">
         <com:BillingPointOfSaleInfo xmlns:com="http://www.travelport.com/schema/common_v28_0" OriginApplication="UAPI" />
         <air:SearchAirLeg>
            <air:SearchOrigin>
               <com:CityOrAirport xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="DXB" />
            </air:SearchOrigin>
            <air:SearchDestination>
               <com:CityOrAirport xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="LGW" />
            </air:SearchDestination>
            <air:SearchDepTime PreferredTime="2015-06-20">
               <com:SearchExtraDays xmlns:com="http://www.travelport.com/schema/common_v28_0" DaysAfter="3" DaysBefore="3" />
            </air:SearchDepTime>
         </air:SearchAirLeg>
         <air:SearchAirLeg>
            <air:SearchOrigin>
               <com:CityOrAirport xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="LGW" />
            </air:SearchOrigin>
            <air:SearchDestination>
               <com:CityOrAirport xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="DXB" />
            </air:SearchDestination>
            <air:SearchDepTime PreferredTime="2015-06-20">
               <com:SearchExtraDays xmlns:com="http://www.travelport.com/schema/common_v28_0" DaysAfter="3" DaysBefore="3" />
            </air:SearchDepTime>
         </air:SearchAirLeg>
         <air:AirSearchModifiers>
            <air:PreferredProviders>
               <com:Provider xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="1G" />
            </air:PreferredProviders>
         </air:AirSearchModifiers>
         <com:SearchPassenger xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="ADT" />
         <com:SearchPassenger xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="CNN" Age="10" />
         <com:SearchPassenger xmlns:com="http://www.travelport.com/schema/common_v28_0" Code="INF" Age="1" />
      </air:LowFareSearchReq>
   </soapenv:Body>
</soapenv:Envelope>';*/
?>
