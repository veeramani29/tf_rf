<?php

class Hybrid_Providers_AOL extends Hybrid_Provider_Model_OpenID
{
	var $openidIdentifier = "http://openid.aol.com/";
}
