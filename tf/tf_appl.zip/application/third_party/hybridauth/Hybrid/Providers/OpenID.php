<?php

class Hybrid_Providers_OpenID extends Hybrid_Provider_Model_OpenID
{
}
