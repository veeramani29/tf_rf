<table border="1" width="200">
<tbody>
<tr>
<td>PROP_NAME</td>
<td>PROP_LATITUDE</td>
<td>PROP_LONGITUDE</td>
</tr>
foreach($all_friends as $row)
 {
<tr>
<td>echo $row->PROP_NAME</td>
<td>echo $row->PROP_LATITUDE</td>
<td>echo $row->PROP_LONGITUDE</td>
</tr>
}</tbody>
</table>