<div class="no_available">
    <div class="noresultimage"><img src="<?php echo ASSETS;?>images/noresult.png" alt="" /></div>
    <h1>There are no cars available. </h1>
    <div class="no_available_text">Sorry, we have no prices for cars in this date range matching your criteria. One or more of your preferences may be affecting the number of exact matches found. Try searching again with a wider search criteria. <br></div>
</div>