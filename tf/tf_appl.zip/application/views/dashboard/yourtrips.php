<!-- Your Trips -->
     <div class="tab-pane padding20me <?php if(!empty($page_type) && $page_type == "trips") {echo "active";} ?>" id="yourtrips">
     	<div class="col-md-3">
          <ul class="sideul">
            <li class="sidepro active"><a href="#urtrips" data-toggle="tab">Your Trips</a></li>
            <li class="sidepro"><a href="#previoustrips" data-toggle="tab">Previous Trips</a></li>
          </ul>
        </div>
        
        <div class="col-md-9">
          <div class="tab-content5">
			<br>
            <div class="tab-pane active" id="urtrips">
            	<span class="size16 padtabne bold">Your Trips</span>
                <div class="withedrow">
                    <div class="rowit">
                        <p class="normalpara">
                      Please verify your email address by clicking the link in the message we just sent to: tobin.provab@gmail.com
                        </p>
                    </div>
                </div>
            </div> 
            <div class="tab-pane" id="previoustrips">
            	<span class="size16 padtabne bold">Previous Trips</span>
                <div class="withedrow">
                    <div class="rowit">
                        <p class="normalpara">
                            Please verify your email address by clicking the link in the message we just sent to:tobin.provab@gmail.com
                        </p>
                    </div>
                </div>
            </div>
             
            
            
            
          </div>
          <div class="clearfix"></div>
        </div>
     </div>
     <!-- Your Trips End-->
