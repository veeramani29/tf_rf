<?php $this->load->view('common/header');?>

<div id="fuornotfour" class="full marintopcnt contentvcr">
    <div class="container">
        <div class="container offset-0">
        	
            <div class="tablwe">
            <div class="col-md-6 celtb">
            	<h2 class="ooops">Access Denied!</h2>
                <span class="erordes">We can't seem to find the page you're looking for.</span>
                <div class="ercod">Timeout</div>
                <div class="rellinks">Here are some helpful links instead:</div>
                  <div class="erorredrctwrp"><a href="<?php echo WEB_URL; ?>" class="erorredrct">Home</a></div>
              
                <div class="erorredrctwrp"><a href="<?php echo WEB_URL; ?>/help" class="erorredrct">Help</a></div>
            </div>
            
            <div class="col-md-6 celtb">
            	<div class="fornot">
                	<img width="300" src="<?php echo ASSETS; ?>images/wired_time_bomb_800_clr_12217.png" alt="" />
                </div>
            </div>
            </div>
            
        </div>
    </div>
</div>

<?php $this->load->view('common/footer');?>
<script type="text/javascript">
/*	$(document).ready(function(){
		var windowht = $(window).height();
		$('#fuornotfour').css({'min-height':windowht})
	});*/
</script>
</body>
</html>
