<?php $this->load->view('common/header');?>

<div id="fuornotfour" class="full marintopcnt contentvcr">
    <div class="container">
        <div class="container offset-0">
        	
            <div class="tablwe">
            <div class="col-md-12 celtb">
            	<h2 class="ooops">Oops!</h2>
                <span class="erordes">You have to login to add the listings please login and continue adding the listings.</span>
                <div class="ercod">&nbsp;</div>
                <div class="rellinks">Here are some helpful links instead:</div>
                <div class="erorredrctwrp"><a href="http://bookhotac.com" class="erorredrct">Home</a></div>
              
                <div class="erorredrctwrp"><a href="http://bookhotac.com/help" class="erorredrct">Help</a></div>
                
            </div>
            
           
            </div>
            
        </div>
    </div>
</div>

<?php $this->load->view('common/footer');?>
<script type="text/javascript">
/*	$(document).ready(function(){
		var windowht = $(window).height();
		$('#fuornotfour').css({'min-height':windowht})
	});*/
</script>
</body>
</html>